const express = require('express');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const userAgent = require('user-agents');

puppeteer.use(StealthPlugin());

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static('.')); // Serve static files
app.use(express.json());

// Real Gmail creation endpoint
app.post('/api/create-gmail', async (req, res) => {
    const { firstName, lastName, password, birthYear, birthMonth, birthDay } = req.body;
    
    try {
        const result = await createGmailAccount({
            firstName,
            lastName,
            password,
            birthYear,
            birthMonth,
            birthDay
        });
        
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

async function createGmailAccount(userData) {
    const browser = await puppeteer.launch({
        headless: 'new',
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
            '--window-size=1920,1080'
        ]
    });

    try {
        const page = await browser.newPage();
        
        // Set random user agent
        await page.setUserAgent(userAgent.toString());
        
        // Navigate to Gmail signup
        await page.goto('https://accounts.google.com/signup/v2/webcreateaccount?flowName=GlifWebSignIn&flowEntry=SignUp', {
            waitUntil: 'networkidle2',
            timeout: 30000
        });

        // Fill in the form
        await page.type('#firstName', userData.firstName);
        await page.type('#lastName', userData.lastName);
        
        // Generate random username
        const randomUsername = `user${Date.now()}${Math.floor(Math.random() * 1000)}`;
        await page.type('#username', randomUsername);
        
        await page.type('#passwd', userData.password);
        await page.type('#confirm-passwd', userData.password);
        
        // Click next
        await page.click('#accountDetailsNext');
        await page.waitForTimeout(2000);

        // Fill phone number (skip for demo)
        await page.waitForSelector('#phoneNumberId', { visible: true });
        await page.click('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button');
        await page.waitForTimeout(2000);

        // Skip phone verification
        await page.click('div[data-id="skip"]');
        await page.waitForTimeout(2000);

        // Fill recovery email (skip)
        await page.click('#view_container > div > div > div.pwWryf.bxPAYd > div > div.zQJV3 > div > div.qhFLie > div > div > button');
        await page.waitForTimeout(2000);

        // Fill birthday
        await page.select('#month', userData.birthMonth.toString());
        await page.type('#day', userData.birthDay.toString());
        await page.type('#year', userData.birthYear.toString());
        
        // Select gender (skip for now)
        await page.select('#gender', '1'); // Male
        
        // Click next
        await page.click('#personalDetailsNext');
        await page.waitForTimeout(3000);

        // Accept terms
        await page.click('#termsofserviceNext');
        await page.waitForTimeout(5000);

        // Get the created email
        const email = `${randomUsername}@gmail.com`;
        
        await browser.close();
        
        return {
            success: true,
            email: email,
            password: userData.password,
            message: 'Account created successfully!'
        };
        
    } catch (error) {
        await browser.close();
        throw new Error(`Failed to create account: ${error.message}`);
    }
}

// Bulk creation endpoint
app.post('/api/bulk-create', async (req, res) => {
    const { count, prefix, firstName, lastName } = req.body;
    
    if (count > 10) {
        return res.status(400).json({ error: 'Maximum 10 accounts per request' });
    }
    
    const results = [];
    
    for (let i = 0; i < count; i++) {
        try {
            const password = generatePassword();
            const birthDate = generateBirthDate();
            
            const result = await createGmailAccount({
                firstName: `${firstName}${i + 1}`,
                lastName: `${lastName}${i + 1}`,
                password: password,
                birthYear: birthDate.year,
                birthMonth: birthDate.month,
                birthDay: birthDate.day
            });
            
            results.push(result);
            
            // Delay between creations
            await new Promise(resolve => setTimeout(resolve, 10000));
            
        } catch (error) {
            results.push({
                success: false,
                error: error.message
            });
        }
    }
    
    res.json({ results });
});

function generatePassword() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%';
    let password = '';
    for (let i = 0; i < 12; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}

function generateBirthDate() {
    const year = 1980 + Math.floor(Math.random() * 25);
    const month = Math.floor(Math.random() * 12) + 1;
    const day = Math.floor(Math.random() * 28) + 1;
    return { year, month, day };
}

app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});