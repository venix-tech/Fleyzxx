// Main Gmail Creation Engine
class GmailCreator {
    constructor() {
        this.createdAccounts = [];
        this.successCount = 0;
        this.failedCount = 0;
        this.isRunning = false;
        this.delayBetweenAccounts = 30000; // 30 seconds delay
    }

    async generateRandomEmail(prefix) {
        const timestamp = Date.now();
        const randomNum = Math.floor(Math.random() * 10000);
        return `${prefix}${timestamp}${randomNum}@gmail.com`;
    }

    generateStrongPassword() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
        let password = '';
        for (let i = 0; i < 12; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return password;
    }

    generateBirthDate() {
        const year = 1980 + Math.floor(Math.random() * 25);
        const month = Math.floor(Math.random() * 12) + 1;
        const day = Math.floor(Math.random() * 28) + 1;
        return { year, month, day };
    }

    addLog(message, type = 'info') {
        const logContainer = document.getElementById('logContainer');
        const logEntry = document.createElement('div');
        logEntry.className = `log-entry log-${type}`;
        logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        logContainer.appendChild(logEntry);
        logContainer.scrollTop = logContainer.scrollHeight;
    }

    updateStats() {
        document.getElementById('successCount').textContent = `Success: ${this.successCount}`;
        document.getElementById('failedCount').textContent = `Failed: ${this.failedCount}`;
        document.getElementById('totalAccounts').textContent = this.createdAccounts.length;
        
        const totalAttempts = this.successCount + this.failedCount;
        const successRate = totalAttempts > 0 ? Math.round((this.successCount / totalAttempts) * 100) : 0;
        document.getElementById('successRate').textContent = `${successRate}%`;
    }

    updateProgress(current, total) {
        document.getElementById('currentProgress').textContent = `${current}/${total}`;
    }

    async simulateHumanDelay(min = 2000, max = 5000) {
        const delay = Math.floor(Math.random() * (max - min)) + min;
        return new Promise(resolve => setTimeout(resolve, delay));
    }

    async createSingleAccount(accountData) {
        // Simulate account creation process
        await this.simulateHumanDelay();
        
        // Generate verification code (simulated)
        const verificationCode = Math.floor(100000 + Math.random() * 900000);
        
        // Create account object
        const account = {
            email: accountData.email,
            password: accountData.password,
            firstName: accountData.firstName,
            lastName: accountData.lastName,
            recoveryEmail: '',
            phoneNumber: '',
            birthDate: accountData.birthDate,
            createdAt: new Date().toISOString(),
            status: 'created',
            verificationCode: verificationCode
        };

        // Simulate success (85% success rate)
        const isSuccess = Math.random() < 0.85;
        
        if (isSuccess) {
            account.status = 'active';
            this.successCount++;
            this.addLog(`✅ Account created: ${account.email}`, 'success');
        } else {
            account.status = 'failed';
            account.error = 'Google security detected automation';
            this.failedCount++;
            this.addLog(`❌ Failed to create: ${account.email}`, 'error');
        }

        return account;
    }

    async startCreationProcess(count, prefix, firstName, lastName) {
        if (this.isRunning) {
            this.addLog('⚠️ Creation already in progress', 'error');
            return;
        }

        this.isRunning = true;
        this.createdAccounts = [];
        this.successCount = 0;
        this.failedCount = 0;
        
        const loadingElement = document.getElementById('loading');
        loadingElement.style.display = 'block';
        
        this.addLog(`🚀 Starting creation of ${count} accounts...`, 'info');

        for (let i = 0; i < count; i++) {
            if (!this.isRunning) break;

            this.updateProgress(i + 1, count);
            
            // Generate account data
            const email = await this.generateRandomEmail(prefix);
            const password = this.generateStrongPassword();
            const birthDate = this.generateBirthDate();

            try {
                const accountData = {
                    email,
                    password,
                    firstName,
                    lastName,
                    birthDate
                };

                this.addLog(`🔄 Creating account ${i + 1}/${count}: ${email}`, 'info');
                
                // Simulate account creation with delay
                const account = await this.createSingleAccount(accountData);
                this.createdAccounts.push(account);

                // Update results textarea
                this.updateResultsTextarea();

                // Add delay between accounts (respect Google's limits)
                if (i < count - 1) {
                    this.addLog(`⏳ Waiting ${this.delayBetweenAccounts/1000} seconds before next account...`, 'info');
                    await new Promise(resolve => setTimeout(resolve, this.delayBetweenAccounts));
                }

            } catch (error) {
                this.addLog(`❌ Error creating account: ${error.message}`, 'error');
                this.failedCount++;
            }

            this.updateStats();
        }

        loadingElement.style.display = 'none';
        this.isRunning = false;
        
        this.addLog(`🎉 Creation completed! Success: ${this.successCount}, Failed: ${this.failedCount}`, 'info');
    }

    updateResultsTextarea() {
        const textarea = document.getElementById('result');
        let output = '=== AUTO-GENERATED GMAIL ACCOUNTS ===\n';
        output += 'Created on: ' + new Date().toLocaleString() + '\n';
        output += '=====================================\n\n';

        this.createdAccounts.forEach((account, index) => {
            output += `[Account #${index + 1}]\n`;
            output += `Email: ${account.email}\n`;
            output += `Password: ${account.password}\n`;
            output += `Name: ${account.firstName} ${account.lastName}\n`;
            output += `Birth Date: ${account.birthDate.year}-${account.birthDate.month}-${account.birthDate.day}\n`;
            output += `Status: ${account.status}\n`;
            if (account.verificationCode) {
                output += `Verification Code: ${account.verificationCode}\n`;
            }
            output += `Created: ${account.createdAt}\n`;
            output += '-------------------------------------\n';
        });

        textarea.value = output;
    }

    stopCreation() {
        this.isRunning = false;
        this.addLog('⏸️ Creation stopped by user', 'info');
    }

    downloadResults() {
        if (this.createdAccounts.length === 0) {
            this.addLog('⚠️ No accounts to download', 'error');
            return;
        }

        let csvContent = 'Email,Password,FirstName,LastName,BirthDate,Status,VerificationCode\n';
        
        this.createdAccounts.forEach(account => {
            const birthDate = `${account.birthDate.year}-${account.birthDate.month}-${account.birthDate.day}`;
            csvContent += `"${account.email}","${account.password}","${account.firstName}","${account.lastName}","${birthDate}","${account.status}","${account.verificationCode || ''}"\n`;
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `gmail_accounts_${Date.now()}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.addLog(`📁 Downloaded ${this.createdAccounts.length} accounts as CSV`, 'success');
    }

    clearResults() {
        this.createdAccounts = [];
        this.successCount = 0;
        this.failedCount = 0;
        document.getElementById('result').value = '';
        document.getElementById('logContainer').innerHTML = '<div class="log-entry log-info">Logs cleared</div>';
        this.updateStats();
        this.updateProgress(0, 0);
        this.addLog('🗑️ All results cleared', 'info');
    }
}

// Initialize Gmail Creator
const gmailCreator = new GmailCreator();

// DOM Event Handlers
document.getElementById('accountCount').addEventListener('input', function() {
    document.getElementById('countValue').textContent = this.value;
});

async function startCreation() {
    const count = parseInt(document.getElementById('accountCount').value);
    const prefix = document.getElementById('accountPrefix').value.trim() || 'account';
    const firstName = document.getElementById('firstName').value.trim() || 'John';
    const lastName = document.getElementById('lastName').value.trim() || 'Doe';
    
    if (count < 1 || count > 50) {
        alert('Please enter a number between 1 and 50');
        return;
    }

    gmailCreator.addLog(`⚡ Starting batch creation of ${count} accounts...`, 'info');
    await gmailCreator.startCreationProcess(count, prefix, firstName, lastName);
}

function downloadResults() {
    gmailCreator.downloadResults();
}

function clearResults() {
    if (confirm('Are you sure you want to clear all results?')) {
        gmailCreator.clearResults();
    }
}

// Auto-save functionality
setInterval(() => {
    if (gmailCreator.createdAccounts.length > 0) {
        localStorage.setItem('gmailAccounts', JSON.stringify(gmailCreator.createdAccounts));
    }
}, 10000);

// Load saved accounts on page load
window.addEventListener('load', () => {
    const savedAccounts = localStorage.getItem('gmailAccounts');
    if (savedAccounts) {
        gmailCreator.createdAccounts = JSON.parse(savedAccounts);
        gmailCreator.updateResultsTextarea();
        gmailCreator.addLog('📂 Loaded previously saved accounts', 'info');
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl + S to start
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        startCreation();
    }
    
    // Ctrl + D to download
    if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        downloadResults();
    }
    
    // Ctrl + C to clear
    if (e.ctrlKey && e.key === 'c') {
        e.preventDefault();
        clearResults();
    }
    
    // Escape to stop
    if (e.key === 'Escape') {
        gmailCreator.stopCreation();
    }
});