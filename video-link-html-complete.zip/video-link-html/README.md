# VideoLink - HTML + Vercel Blob

Folder `public/` berisi HTML publik yang bisa dilihat/diedit:
- `public/index.html` = halaman upload
- `public/vid/index.html` = template halaman video
- `public/upload.js` = upload + generate link
- `public/style.css` = tampilan

`/vid/ID` membutuhkan rewrite ke `public/vid/index.html`; API mengembalikan URL Blob untuk ID tersebut.

Untuk penyimpanan: hubungkan Vercel Blob dan set `BLOB_READ_WRITE_TOKEN`.
Set `NEXT_PUBLIC_SITE_URL` ke domain kamu.

Catatan: HTML statis sendiri tidak dapat menyimpan file upload. Backend/API + Blob diperlukan.
